const path = require("path");
const express = require("express");
const { homedir } = require("os");
const app = express();

// console.log(__dirname);

// console.log(path.join(__dirname, "../public"));

const staticPath = path.join(__dirname, "../public"); 

//built in middleware
 app.use(express.static(staticPath));

app.get("/home.html",function(req,res) {
    res.send(__dirname+"/"+"home.html")
});

app.get("/home.html",function(req,res){
    res.send(__dirname+"/"+"about.html")
});

app.get("/login.html",function(req,res){
    res.send(__dirname+"/"+"login.html")
});

app.get("/apply.html",function(req,res){
    res.send(__dirname+"/"+"apply.html")
});

app.get("/services.html",function(req,res){
    res.send(__dirname+"/"+"services.html")
});

app.get("/done.html",function(req,res){
    res.send(__dirname+"/"+"done.html")
});

app.listen(8000, () => {
    console.log("listening the port at 8000");
});